//
//  ViewController.swift
//  Calculator_O_mobile
//
//  Created by sher on 13/7/22.
//

import UIKit
import SnapKit
class Viewer: UIViewController {

    var controller: Controller?
    
    required init?(coder: NSCoder) {
        print("i'm viewer object")
        super.init(coder: coder)
        controller = Controller(viewer: self)
    }
    //==============================
    var userTyped = false
    var oper = ""
    var label = ""
    var labelString = [String]()
    var firstNumber: UILabel = {
        let label = UILabel()
        label.text = "0"
        label.font = UIFont(name: "AvenirNext-regular", size: 40)
        label.textColor = .white
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    //MARK: add Views and Buttons
    let clearButton: UIButton = {
        let button = UIButton()
        button.setTitle("AC", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.titleLabel?.font = UIFont(name: "AvenirNext-Bold", size: 25)
        button.setTitleColor(UIColor.black, for: .normal)
        button.backgroundColor = .gray
        button.layer.cornerRadius = 10
        return button
    }()
    let plusORminusButton: UIButton = {
        let button = UIButton()
        button.setTitle("+/-", for: .normal)
        button.titleLabel?.font = UIFont(name: "AvenirNext-Bold", size: 23)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = .gray
        button.layer.cornerRadius = 10
        return button
    }()
    let percentButton: UIButton = {
        let button = UIButton()
        button.setTitle("%", for: .normal)
        button.titleLabel?.font = UIFont(name: "AvenirNext-Bold", size: 23)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = .gray
        button.layer.cornerRadius = 10
        return button
    }()
    
    let division: UIButton = {
        let button = UIButton()
        button.setTitle("/", for: .normal)
        button.titleLabel?.font = UIFont(name: "AvenirNext-Bold", size: 23)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = .orange
        button.layer.cornerRadius = 10
        return button
    }()
    
    let multiplyMutton: UIButton = {
        let button = UIButton()
        button.setTitle("*", for: .normal)
        button.titleLabel?.font = UIFont(name: "AvenirNext-Bold", size: 23)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = .orange
        button.layer.cornerRadius = 10
        return button
    }()
    let minusButton: UIButton = {
        let button = UIButton()
        button.setTitle("-", for: .normal)
        button.titleLabel?.font = UIFont(name: "AvenirNext-Bold", size: 23)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = .orange
        button.layer.cornerRadius = 10
        return button
    }()
    
    let plusButton: UIButton = {
        let button = UIButton()
        button.setTitle("+", for: .normal)
        button.titleLabel?.font = UIFont(name: "AvenirNext-Bold", size: 23)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = .orange
        button.layer.cornerRadius = 10
        return button
    }()
    let equalToButton: UIButton = {
        let button = UIButton()
        button.setTitle("=", for: .normal)
        button.titleLabel?.font = UIFont(name: "AvenirNext-Bold", size: 23)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = .orange
        button.layer.cornerRadius = 10
        return button
    }()
    
    //MARK: Numbers
    let sevenButton: UIButton = {
        let button = UIButton()
        button.setTitle("7", for: .normal)
        button.titleLabel?.font = UIFont(name: "AvenirNext-Bold", size: 23)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = .darkGray
        button.layer.cornerRadius = 10
        return button
    }()
    
    let fourButton: UIButton = {
        let button = UIButton()
        button.setTitle("4", for: .normal)
        button.titleLabel?.font = UIFont(name: "AvenirNext-Bold", size: 23)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = .darkGray
        button.layer.cornerRadius = 10
        return button
    }()
    
    let oneButton: UIButton = {
        let button = UIButton()
        button.setTitle("1", for: .normal)
        button.titleLabel?.font = UIFont(name: "AvenirNext-Bold", size: 23)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = .darkGray
        button.layer.cornerRadius = 10
        return button
    }()
    let zeroButton: UIButton = {
        let button = UIButton()
        button.setTitle("0", for: .normal)
        button.titleLabel?.font = UIFont(name: "AvenirNext-Bold", size: 23)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = .darkGray
        button.layer.cornerRadius = 10
        return button
    }()
    
    let eightButton: UIButton = {
        let button = UIButton()
        button.setTitle("8", for: .normal)
        button.titleLabel?.font = UIFont(name: "AvenirNext-Bold", size: 23)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = .darkGray
        button.layer.cornerRadius = 10
        return button
    }()
    let fiveButton: UIButton = {
        let button = UIButton()
        button.setTitle("5", for: .normal)
        button.titleLabel?.font = UIFont(name: "AvenirNext-Bold", size: 23)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = .darkGray
        button.layer.cornerRadius = 10
        return button
    }()
    let twoButton: UIButton = {
        let button = UIButton()
        button.setTitle("2", for: .normal)
        button.titleLabel?.font = UIFont(name: "AvenirNext-Bold", size: 23)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = .darkGray
        button.layer.cornerRadius = 10
        return button
    }()
    
    let nineButton: UIButton = {
        let button = UIButton()
        button.setTitle("9", for: .normal)
        button.titleLabel?.font = UIFont(name: "AvenirNext-Bold", size: 23)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = .darkGray
        button.layer.cornerRadius = 10
        return button
    }()
    let sixButton: UIButton = {
        let button = UIButton()
        button.setTitle("6", for: .normal)
        button.titleLabel?.font = UIFont(name: "AvenirNext-Bold", size: 23)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = .darkGray
        button.layer.cornerRadius = 10
        return button
    }()
    let threebutton: UIButton = {
        let button = UIButton()
        button.setTitle("3", for: .normal)
        button.titleLabel?.font = UIFont(name: "AvenirNext-Bold", size: 23)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = .darkGray
        button.layer.cornerRadius = 10
        return button
    }()
    let dropButton: UIButton = {
        let button = UIButton()
        button.setTitle(".", for: .normal)
        button.titleLabel?.font = UIFont(name: "AvenirNext-Bold", size: 23)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = .darkGray
        button.layer.cornerRadius = 10
        return button
    }()
    
    //MARK: MainView
    let mainView: UIView = {
        let stack = UIView()
        stack.translatesAutoresizingMaskIntoConstraints = false
        return stack
    }()
    //MARK: viewdidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        AddViews()
        setupButtons()
        setupMainStack()
        setupLabel()
        addTarget()
        view.backgroundColor = .black
        
    }
    //================================================
    //MARK: addViews
    private func AddViews() {
        view.addSubview(mainView)
        //MARK: add Label
        view.addSubview(firstNumber)
        //==============================
        //MARK: addStack
        mainView.addSubview(clearButton)
        mainView.addSubview(plusORminusButton)
        mainView.addSubview(percentButton)
        mainView.addSubview(division)
        mainView.addSubview(multiplyMutton)
        mainView.addSubview(minusButton)
        mainView.addSubview(plusButton)
        mainView.addSubview(equalToButton)
        //MARK: addNumbers
        mainView.addSubview(sevenButton)
        mainView.addSubview(fourButton)
        mainView.addSubview(oneButton)
        mainView.addSubview(zeroButton)
        mainView.addSubview(eightButton)
        mainView.addSubview(fiveButton)
        mainView.addSubview(twoButton)
        mainView.addSubview(nineButton)
        mainView.addSubview(threebutton)
        mainView.addSubview(sixButton)
        mainView.addSubview(dropButton)
    }
    //MARK: setupLabel
    private func setupLabel() {
        
        firstNumber.snp.makeConstraints { make in
            make.bottom.equalTo(mainView.snp.top).offset(-20)
            make.leading.equalTo(view.snp.leading).offset(20)
            make.trailingMargin.equalTo(view.snp.trailingMargin)
            make.height.equalTo(60)
            
        }
       
    }
    
    //MARK: setupMainStack
    
    private func setupMainStack() {
        mainView.snp.makeConstraints { make in
            make.leading.equalTo(view.snp.leading)
            make.trailing.equalTo(view.snp.trailing)
            make.bottom.equalTo(view.snp.bottom)
        }
    }
    //MARK: setupButtons
    private func setupButtons() {
        clearButton.snp.makeConstraints { make in
            make.leading.equalTo(mainView.snp.leading).offset(10)
            make.topMargin.equalTo(mainView.snp.topMargin).offset(10)
            make.height.equalTo(70)
            make.width.equalTo(70)
        }
        plusORminusButton.snp.makeConstraints { make in
            make.leading.equalTo(clearButton.snp.trailing).offset(10)
            make.topMargin.equalTo(mainView.snp.topMargin).offset(10)
            make.height.equalTo(70)
            make.width.equalTo(70)
        }
        percentButton.snp.makeConstraints { make in
            make.leading.equalTo(plusORminusButton.snp.trailing).offset(10)
            make.topMargin.equalTo(mainView.snp.topMargin).offset(10)
            make.height.equalTo(70)
            make.width.equalTo(70)
        }
        division.snp.makeConstraints { make in

            make.trailing.equalTo(mainView.snp.trailing).offset(-10)
            make.topMargin.equalTo(mainView.snp.topMargin).offset(10)
            make.leading.equalTo(percentButton.snp.trailing).offset(10)
            make.height.equalTo(70)
            make.width.equalTo(70)
        }

        multiplyMutton.snp.makeConstraints { make in
            make.trailing.equalTo(mainView.snp.trailing).offset(-10)
            make.top.equalTo(division.snp.bottom).offset(10)
            make.leading.equalTo(percentButton.snp.trailing).offset(10)
            make.height.equalTo(70)
            make.width.equalTo(70)
        }
        minusButton.snp.makeConstraints { make in
            make.trailing.equalTo(mainView.snp.trailing).offset(-10)
            make.top.equalTo(multiplyMutton.snp.bottom).offset(10)
            make.leading.equalTo(percentButton.snp.trailing).offset(10)
            make.height.equalTo(70)
            make.width.equalTo(70)
        }

        plusButton.snp.makeConstraints { make in
            make.trailing.equalTo(mainView.snp.trailing).offset(-10)
            make.top.equalTo(minusButton.snp.bottom).offset(10)
            make.leading.equalTo(percentButton.snp.trailing).offset(10)
            make.height.equalTo(70)
            make.width.equalTo(70)
        }
        equalToButton.snp.makeConstraints { make in
            make.trailing.equalTo(mainView.snp.trailing).offset(-10)
            make.top.equalTo(plusButton.snp.bottom).offset(10)
            make.leading.equalTo(dropButton.snp.trailing).offset(10)
            make.bottomMargin.equalTo(mainView.snp.bottomMargin).offset(-10)
            make.height.equalTo(70)
            make.width.equalTo(70)
        }

        //MARK: Numbers layers
        sevenButton.snp.makeConstraints { make in
            make.leading.equalTo(mainView.snp.leading).offset(10)
            make.top.equalTo(clearButton.snp.bottom).offset(10)
            make.height.equalTo(70)
            make.width.equalTo(70)
        }
        fourButton.snp.makeConstraints { make in
            make.leading.equalTo(mainView.snp.leading).offset(10)
            make.top.equalTo(sevenButton.snp.bottom).offset(10)
            make.height.equalTo(70)
            make.width.equalTo(70)
        }
        oneButton.snp.makeConstraints { make in
            make.leading.equalTo(mainView.snp.leading).offset(10)
            make.top.equalTo(fourButton.snp.bottom).offset(10)
            make.height.equalTo(70)
            make.width.equalTo(70)
        }
        
        eightButton.snp.makeConstraints { make in
            make.leading.equalTo(clearButton.snp.trailing).offset(10)
            make.top.equalTo(clearButton.snp.bottom).offset(10)
            make.bottomMargin.equalTo(mainView.snp.bottomMargin)
            make.height.equalTo(70)
            make.width.equalTo(70)
        }
        fiveButton.snp.makeConstraints { make in
            make.leading.equalTo(clearButton.snp.trailing).offset(10)
            make.top.equalTo(eightButton.snp.bottom).offset(10)
            make.height.equalTo(70)
            make.width.equalTo(70)
        }
        twoButton.snp.makeConstraints { make in
            make.leading.equalTo(clearButton.snp.trailing).offset(10)
            make.top.equalTo(fiveButton.snp.bottom).offset(10)
            make.height.equalTo(70)
            make.width.equalTo(70)
        }
        nineButton.snp.makeConstraints { make in
            make.leading.equalTo(plusORminusButton.snp.trailing).offset(10)
            make.top.equalTo(percentButton.snp.bottom).offset(10)
            make.trailing.equalTo(division.snp.leading).offset(-10)
            make.height.equalTo(70)
            make.width.equalTo(70)
        }
        sixButton.snp.makeConstraints { make in
            make.leading.equalTo(plusORminusButton.snp.trailing).offset(10)
            make.top.equalTo(nineButton.snp.bottom).offset(10)
            make.trailing.equalTo(division.snp.leading).offset(-10)
            make.height.equalTo(70)
            make.width.equalTo(70)
        }
        threebutton.snp.makeConstraints { make in
            make.leading.equalTo(plusORminusButton.snp.trailing).offset(10)
            make.top.equalTo(sixButton.snp.bottom).offset(10)
            make.height.equalTo(70)
            make.trailing.equalTo(division.snp.leading).offset(-10)
            make.width.equalTo(70)
        }
        zeroButton.snp.makeConstraints { make in
            make.leading.equalTo(mainView.snp.leading).offset(10)
            make.top.equalTo(oneButton.snp.bottom).offset(10)
            make.bottomMargin.equalTo(mainView.snp.bottomMargin).offset(-10)
            make.height.equalTo(70)
            make.width.equalTo(140)
        }
        dropButton.snp.makeConstraints { make in
            make.leading.equalTo(zeroButton.snp.trailing).offset(10)
            make.top.equalTo(threebutton.snp.bottom).offset(10)
            make.height.equalTo(70)
            make.trailing.equalTo(threebutton.snp.trailing)
            make.bottomMargin.equalTo(mainView.snp.bottomMargin).offset(-10)
            make.width.equalTo(70)
        }
    }
    //=======================addTARGETS=========================
    private func addTarget() {
        //MARK: operations
        let clearAll = UITapGestureRecognizer(target: self, action: #selector(clearFunc))
        clearButton.addGestureRecognizer(clearAll)
        clearButton.isUserInteractionEnabled = true
        let plusORminus = UITapGestureRecognizer(target: self, action: #selector(operationsFunc))
        plusORminusButton.addGestureRecognizer(plusORminus)
        plusORminusButton.isUserInteractionEnabled = true
        let percent = UITapGestureRecognizer(target: self, action: #selector(operationsFunc))
        percentButton.addGestureRecognizer(percent)
        percentButton.isUserInteractionEnabled = true
        let divisionbutton = UITapGestureRecognizer(target: self, action: #selector(operationsFunc))
        division.addGestureRecognizer(divisionbutton)
        division.isUserInteractionEnabled = true
        let multiply = UITapGestureRecognizer(target: self, action: #selector(operationsFunc))
        multiplyMutton.addGestureRecognizer(multiply)
        multiplyMutton.isUserInteractionEnabled = true
        let minus = UITapGestureRecognizer(target: self, action: #selector(operationsFunc))
        minusButton.addGestureRecognizer(minus)
        minusButton.isUserInteractionEnabled = true
        let plus = UITapGestureRecognizer(target: self, action: #selector(operationsFunc))
        plusButton.addGestureRecognizer(plus)
        plusButton.isUserInteractionEnabled = true
        let equalto = UITapGestureRecognizer(target: self, action: #selector(equalToFunc))
        equalToButton.addGestureRecognizer(equalto)
        equalToButton.isUserInteractionEnabled = true
        let decimal = UITapGestureRecognizer(target: self, action: #selector(decimalFunc))
        dropButton.addGestureRecognizer(decimal)
        dropButton.isUserInteractionEnabled = true
        //MARK: numbers
        let zero = UITapGestureRecognizer(target: self, action: #selector(numbersFunc))
        zeroButton.addGestureRecognizer(zero)
        zeroButton.isUserInteractionEnabled = true
        let one = UITapGestureRecognizer(target: self, action: #selector(numbersFunc))
        oneButton.addGestureRecognizer(one)
        oneButton.isUserInteractionEnabled = true
        let two = UITapGestureRecognizer(target: self, action: #selector(numbersFunc))
        twoButton.addGestureRecognizer(two)
        twoButton.isUserInteractionEnabled = true
        let three = UITapGestureRecognizer(target: self, action: #selector(numbersFunc))
        threebutton.addGestureRecognizer(three)
        threebutton.isUserInteractionEnabled = true
        let four = UITapGestureRecognizer(target: self, action: #selector(numbersFunc))
        fourButton.addGestureRecognizer(four)
        fourButton.isUserInteractionEnabled = true
        let five = UITapGestureRecognizer(target: self, action: #selector(numbersFunc))
        fiveButton.addGestureRecognizer(five)
        fiveButton.isUserInteractionEnabled = true
        let six = UITapGestureRecognizer(target: self, action: #selector(numbersFunc))
        sixButton.addGestureRecognizer(six)
        sixButton.isUserInteractionEnabled = true
        let seven = UITapGestureRecognizer(target: self, action: #selector(numbersFunc))
        sevenButton.addGestureRecognizer(seven)
        sevenButton.isUserInteractionEnabled = true
        let eight = UITapGestureRecognizer(target: self, action: #selector(numbersFunc))
        eightButton.addGestureRecognizer(eight)
        eightButton.isUserInteractionEnabled = true
        let nine = UITapGestureRecognizer(target: self, action: #selector(numbersFunc))
        nineButton.addGestureRecognizer(nine)
        nineButton.isUserInteractionEnabled = true
    }
    //============================================================
    
    //MARK: Logic
    public func update(result: String) {
        firstNumber.text = "\(result)"
    }
    
    //MARK: clearFunc
    @objc func clearFunc(sender: UITapGestureRecognizer) {
        oper = sender.view?.largeContentTitle ?? ""
        if oper == "AC" {
            firstNumber.text = ""
            label = ""
            userTyped = false
        }
    }
    //MARK: operationsFunc
    @objc func operationsFunc(sender: UITapGestureRecognizer) {
        oper = sender.view?.largeContentTitle ?? ""
        label = " "
        if userTyped {
            if oper == "+/-" {
                print(label)
                label = self.firstNumber.text!
                self.firstNumber.text! = ""
                self.firstNumber.text! += "-\(label)"
                label += self.firstNumber.text!
            } else {
                self.firstNumber.text! = self.firstNumber.text! + " \(oper) "
            }
        }
    }
    //MARK: equalToFunc
    @objc func equalToFunc(sender: UITapGestureRecognizer) {
        if sender.view?.largeContentTitle == "=" {
            controller?.CalcResult(label: label)
            label = ""
        }
    }
    //MARK: numbersFunc
    @objc func numbersFunc(sender: UITapGestureRecognizer) {
     let number = sender.view?.largeContentTitle
     if userTyped {
         self.firstNumber.text! = self.firstNumber.text! + "\(number ?? "")"
         label = ""
         label = " \(self.firstNumber.text!)"
     } else {
         self.firstNumber.text = "\(number!)"
         userTyped = true
        }
    }
    //MARK: decimalFunc
    @objc func decimalFunc(sender: UITapGestureRecognizer) {
        label = ""
        let decimal = sender.view?.largeContentTitle
        if userTyped {
            firstNumber.text = firstNumber.text! + "\(decimal ?? "")"
        }
        else{
            firstNumber.text = ("0")
        }
    }
    override func didReceiveMemoryWarning() {
           super.didReceiveMemoryWarning()
           // Dispose of any resources that can be recreated.
       }
    
}
