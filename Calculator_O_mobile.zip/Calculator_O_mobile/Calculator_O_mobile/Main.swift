//
//  AppDelegate.swift
//  Calculator_O_mobile
//
//  Created by sher on 13/7/22.
//

import UIKit

@main
class Main: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    override init() {
        print("AppDelegate object")
    }

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        return true
    }

    


}

